// Modular data-ingestion pipeline.
// DataSource interface: async loadSession(ticker, dateStr) -> Session
//   Session = { ticker, name, date, prevClose, prices: Float64Array(23400), vols: Float32Array(23400) }
//   One tick per second, 09:30:00–15:59:59 ET (390 min).
// SyntheticYahooSource generates deterministic per-second ticks the way a real
// YahooFinanceSource would after interpolating 1m bars (Yahoo serves 1m at best);
// swap in a live fetcher by implementing the same interface in createDataSource().

export const SESSION_SECONDS = 23400;
export const TICKERS = {
  AAPL: { name: 'Apple Inc.', base: 233.4, vol: 0.014, adv: 58e6 },
  MSFT: { name: 'Microsoft Corp.', base: 498.8, vol: 0.012, adv: 22e6 },
  NVDA: { name: 'NVIDIA Corp.', base: 172.4, vol: 0.024, adv: 210e6 },
  TSLA: { name: 'Tesla Inc.', base: 316.9, vol: 0.032, adv: 95e6 },
  SPY: { name: 'SPDR S&P 500 ETF', base: 627.6, vol: 0.008, adv: 48e6 },
};

export function hashStr(s) {
  let h = 1779033703 ^ s.length;
  for (let i = 0; i < s.length; i++) { h = Math.imul(h ^ s.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
  return h >>> 0;
}
export function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function gauss(rnd) {
  let u = 0, v = 0;
  while (u === 0) u = rnd();
  while (v === 0) v = rnd();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

// U-shaped intraday volatility/volume multiplier, m in [0, 390)
function uShape(m) {
  const x = m / 390;
  return 0.65 + 1.4 * (Math.pow(1 - x, 6) + Math.pow(x, 8));
}

class SyntheticYahooSource {
  async loadSession(ticker, dateStr) {
    const spec = TICKERS[ticker];
    if (!spec) throw new Error('Unknown ticker: ' + ticker);
    const rnd = mulberry32(hashStr(ticker + '|' + dateStr));
    const prevClose = spec.base * (1 + (rnd() - 0.5) * 0.06);
    // --- stage 1: 390 one-minute closes (what Yahoo 1m bars give) ---
    const minSigma = spec.vol / Math.sqrt(390);
    const drift = (rnd() - 0.5) * 2 * spec.vol / 390;
    const gapPct = gauss(rnd) * spec.vol * 0.35;
    const minutes = new Float64Array(391);
    minutes[0] = prevClose * (1 + gapPct);
    let mom = 0;
    for (let m = 1; m <= 390; m++) {
      mom = mom * 0.92 + gauss(rnd) * 0.08; // AR(1) momentum regimes
      const r = drift + (gauss(rnd) + mom * 2.2) * minSigma * uShape(m - 1);
      minutes[m] = minutes[m - 1] * (1 + r);
    }
    // --- stage 2: interpolate seconds (Brownian bridge inside each minute) ---
    const prices = new Float64Array(SESSION_SECONDS);
    const vols = new Float32Array(SESSION_SECONDS);
    const secSigma = minSigma / Math.sqrt(60) * 1.15;
    for (let m = 0; m < 390; m++) {
      const p0 = minutes[m], p1 = minutes[m + 1];
      const minuteVol = (spec.adv / 390) * uShape(m) * Math.exp(gauss(rnd) * 0.55);
      let p = p0;
      for (let s = 0; s < 60; s++) {
        const i = m * 60 + s;
        const remain = 60 - s;
        // bridge pull toward p1 + independent noise
        p = p + (p1 - p) / remain + gauss(rnd) * secSigma * p;
        prices[i] = Math.round(p * 100) / 100;
        const burst = rnd() < 0.04 ? 4 + rnd() * 10 : 1;
        vols[i] = Math.max(0, Math.round((minuteVol / 60) * burst * (0.25 + rnd() * 1.5)));
      }
      prices[m * 60 + 59] = Math.round(p1 * 100) / 100;
    }
    return { ticker, name: spec.name, date: dateStr, prevClose: Math.round(prevClose * 100) / 100, prices, vols };
  }
}

export function createDataSource() { return new SyntheticYahooSource(); }
